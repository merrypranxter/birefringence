// TODO: fields/stress-field.glsl
