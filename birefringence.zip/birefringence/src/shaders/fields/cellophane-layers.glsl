// TODO: fields/cellophane-layers.glsl
