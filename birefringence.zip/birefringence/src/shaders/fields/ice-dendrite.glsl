// TODO: fields/ice-dendrite.glsl
