// TODO: fields/crystal-thickness.glsl
