// birefringence — michel-levy.js
// Retardance → RGB spectral-sum table / LUT builder.
