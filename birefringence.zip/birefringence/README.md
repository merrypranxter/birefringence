# birefringence

A creative coding project exploring **crossed-polarizer interference colors** — the Michel-Lévy effect where birefringent materials retard light by thickness × Δn, producing spectral rainbows between crossed polarizers. Photoelastic stress fringes, mineral thin-sections, cellophane layers, sugar crystals. Rainbow-mathy.

## What Is This?

A **generator** that simulates the physics of birefringence: a material with two different refractive indices retards light passing through it. Between crossed polarizers, that retardance becomes color. The color is not arbitrary — it is the spectral interference `sin²(πΓ/λ)` summed across the visible spectrum. The result is physics-generated rainbows.

**Bonus:** Can read `u_source` luminance as a thickness field to push any image through the simulated birefringent medium.

## Project Structure

```
src/
  js/
    main.js           — WebGL setup, render loop, parameter UI
    michel-levy.js    — retardance → RGB spectral-sum table / LUT
    color-maps.js     — palette utilities
  shaders/
    fields/           — swappable retardance sources
      stress-field.glsl     — photoelastic stress (point loads / cracks)
      crystal-thickness.glsl — random crystalline domains
      cellophane-layers.glsl — flat stacked regions
      ice-dendrite.glsl     — crystallizing thickness field
    retardance.frag   — build Γ = thickness · Δn field
    interference.frag — sin²(πΓ/λ) summed over spectrum → RGB
    post-process.frag — glassy specular + bloom
```

## Running

Open `index.html` in any modern browser. WebGL2 required.

## Current Field Engines

- [ ] _stress_field — photoelastic stress from point loads/cracks → screaming fringes
- [ ] _crystal_thickness — random domains, mineral thin-section look
- [ ] _cellophane_layers — flat stacked regions, Mondrian-style color blocks
- [ ] _ice_dendrite — radial thickness, fine high-order fringes

## Aesthetic Regimes

- [ ] photoelastic_stress — stressed bracket, black field, stress rainbows
- [ ] mineral_thin_section — random domains, Michel-Lévy orders, geology-slide look
- [ ] cellophane_mondrian — flat layered regions, rotating analyzer cycles palette
- [ ] sugar_crystal — radial thickness, fine high-order fringes

## Parameters

- `field_source` — stress_field | crystal_thickness | cellophane_layers | ice_dendrite
- `retardance_scale` — 0–5000 nm (scales thickness → color order)
- `analyzer_angle` — 0°–90° (rotates the whole palette)
- `wave_plate` — none | full | quarter (offsets color order)
- `order` — 1–8 (Michel-Lévy order)

## Ecosystem Hooks

Shares spectral-color logic with `thin_film_iridescence`, `structural_color`. Pairs with `crystalline`, `minerals`, `op_art_style`. Rainbow-weird.

---

*The color is not painted — it is the physics of light fighting through matter.*
