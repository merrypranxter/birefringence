# Math Reference

## Core Equations

*(TBD — populate from repo_seed.txt math sections.)*

## Shader Snippets

*(TBD — key GLSL implementations.)*

## References

*(TBD — papers, standards, canonical sources.)*
